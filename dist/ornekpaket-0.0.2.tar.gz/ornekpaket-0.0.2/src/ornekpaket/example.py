def add_one(number):
    return number + 1


def seyhello():
    print("Hola")